//
//  PPFieldOfViewOverlayViewController.h
//  PhotoPayFramework
//
//  Created by Jura on 18/06/14.
//  Copyright (c) 2014 MicroBlink Ltd. All rights reserved.
//

#import "PPBasePhotoPayOverlayViewController.h"
#import "PPModernBaseOverlayViewController.h"

PP_CLASS_AVAILABLE_IOS(6.0)
@interface PPFieldOfViewOverlayViewController : PPModernBaseOverlayViewController

@end
