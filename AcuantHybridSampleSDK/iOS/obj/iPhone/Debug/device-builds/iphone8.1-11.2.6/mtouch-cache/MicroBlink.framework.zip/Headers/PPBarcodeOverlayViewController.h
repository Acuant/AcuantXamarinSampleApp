//
//  PPBarcodeOverlayViewController.h
//  BarcodeFramework
//
//  Created by Jura on 22/12/13.
//  Copyright (c) 2015 MicroBlink Ltd. All rights reserved.
//

#import "PPBaseBarcodeOverlayViewController.h"

PP_CLASS_AVAILABLE_IOS(6.0)
@interface PPBarcodeOverlayViewController : PPBaseBarcodeOverlayViewController

@end
