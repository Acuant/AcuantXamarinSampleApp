//
//  PPModernToastOverlaySubview.h
//  PhotoPayFramework
//
//  Created by Marko Mihovilić on 04/09/14.
//  Copyright (c) 2014 MicroBlink Ltd. All rights reserved.
//

#import "PPOverlaySubview.h"

NS_ASSUME_NONNULL_BEGIN

PP_CLASS_AVAILABLE_IOS(6.0)
@interface PPModernToastOverlaySubview : PPOverlaySubview

@end

NS_ASSUME_NONNULL_END
